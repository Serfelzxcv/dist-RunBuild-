import { c as createComponent, r as renderTemplate, a as renderComponent, m as maybeRenderHead } from './astro/server_0co4pQTh.mjs';
import 'kleur/colors';
import 'html-escaper';
import 'react/jsx-runtime';
import 'react';
import { o as opcion1, j as opcion2, $ as $$Layout } from './index_BGGjwlG8.mjs';
import { H as Hero } from './index_BHZt_sSi.mjs';

const $$Index = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "SchanauzerTech | Inicio", "description": "Desarrollo de Software - Paginas Web - Desarrollo Mobile" }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<main class="page-content"> ${renderComponent($$result2, "Hero", Hero, { "client:load": true, "heroType": "fullPageSlider", "data": [
    {
      subtitle: "Schnauzer Tech",
      title: "Software",
      background: opcion1.src,
      paragraph: "Si est\xE1s buscando una agencia que te ayude a crear una presencia online notable, has llegado al lugar correcto. Podemos ayudarte a llevar tu negocio al siguiente nivel.",
      button: {
        text: "Informaci\xF3n",
        link: "/servicios"
      }
    },
    {
      subtitle: "Calidad, Confianza, Seguridad ",
      title: "Soluci\xF3n",
      background: opcion2.src,
      paragraph: "",
      button: {
        text: "Informaci\xF3n",
        link: "/servicios"
      }
    }
  ], "client:component-hydration": "load", "client:component-path": "@modules/Hero", "client:component-export": "Hero" })} </main> ` })}`;
}, "C:/Proyectos/SchnauzerTech/cybernetic-free/src/pages/index.astro", void 0);

const $$file = "C:/Proyectos/SchnauzerTech/cybernetic-free/src/pages/index.astro";
const $$url = "";

export { $$Index as default, $$file as file, $$url as url };
