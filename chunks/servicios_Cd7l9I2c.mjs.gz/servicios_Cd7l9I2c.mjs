import { c as createComponent, r as renderTemplate, a as renderComponent, m as maybeRenderHead } from './astro/server_0co4pQTh.mjs';
import 'kleur/colors';
import 'html-escaper';
import { T as Theme, M as MediaQuery, F as FadeIn, C as Container, p as portada, d as desarrolloWeb, b as desarrollomovil, c as automatizacion, e as chatbot, f as consultoria, g as ecomerce, i as especialistas, $ as $$Layout } from './index_BGGjwlG8.mjs';
import { H as Hero } from './index_BHZt_sSi.mjs';
import { jsx, jsxs } from 'react/jsx-runtime';
import 'react';
import styled from '@emotion/styled';
import { T as TextBox } from './index_BvAwbjsn.mjs';
import { F as Footer } from './index_D_2I4jLu.mjs';

const ServiceCardsStyled = styled.section`
    background: ${Theme.primary};
    padding-top: 90px;
    border-top-left-radius: 50px;
    border-top-right-radius: 50px;
    margin: -43px 0 50px;
    z-index: 1;
    position: relative;
    padding-bottom: 70px;
`;
const ServiceCardsHeading = styled.div`
    color: ${Theme.secondary};

    margin-bottom: 40px;
    max-width: 550px;

    p {
        color: ${Theme.tertiary};
    }

    h2 {
        font-size: 60px;
        line-height: 1.2;
        margin-bottom: 10px;

        ${MediaQuery.max("lg")} {
            font-size: 40px;
            line-height: 1.2;
        }
    }
`;
const ServiceCardsGrid = styled.div`
    background: ${Theme.cuaternary};
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 40px;
    padding: 40px;
    border-radius:20px;

    ${MediaQuery.max("lg")} {
        grid-template-columns: 1fr;
        gap: 20px;
    }

    h3 {
        font-size: 20px;
        line-height: 1.2;
        margin-bottom: 5px;
    }

    p {
        margin: 0;
        font-size: 16px;
        line-height: 1.2;
        letter-spacing: -0.5px;
        opacity: 0.8;
    }
    img {
        width: 100%;
        height: 150px;
        
        object-fit:cover;
        margin-bottom: 10px;
    }

    
`;

const ServiceCards = ({
  cards,
  description,
  title
}) => {
  if (!cards || !cards.length) {
    return null;
  }
  const cardsElements = cards.map((card, index) => {
    return /* @__PURE__ */ jsx(FadeIn, { children: /* @__PURE__ */ jsxs(TextBox, { children: [
      /* @__PURE__ */ jsx("img", { src: card.image, alt: card.title }),
      /* @__PURE__ */ jsx("h3", { children: card.title }),
      /* @__PURE__ */ jsx("p", { children: card.description })
    ] }) }, index);
  });
  return /* @__PURE__ */ jsx(ServiceCardsStyled, { children: /* @__PURE__ */ jsxs(Container, { children: [
    title && description && /* @__PURE__ */ jsx(FadeIn, { children: /* @__PURE__ */ jsxs(ServiceCardsHeading, { children: [
      description && /* @__PURE__ */ jsx("p", { children: description }),
      title && /* @__PURE__ */ jsx("h2", { children: title })
    ] }) }),
    /* @__PURE__ */ jsx(ServiceCardsGrid, { children: cardsElements })
  ] }) });
};

const $$Servicios = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "Cybernetic | Servicios", "description": "YOUR META DESCRIPTION FOR SEO" }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<main class="page-content"> ${renderComponent($$result2, "Hero", Hero, { "heroType": "ParallaxImage", "client:visible": true, "data": {
    image: portada.src,
    content: {
      title: "Servicios",
      paragraph: "Ofrecemos desarrollo de software personalizado, desde aplicaciones m\xF3viles hasta soluciones empresariales, con eficiencia y calidad"
    }
  }, "client:component-hydration": "visible", "client:component-path": "@modules/Hero", "client:component-export": "Hero" })} ${renderComponent($$result2, "ServiceCards", ServiceCards, { "description": "Servicios", "title": "El Soporte que Tenemos para Ti", "client:visible": true, "cards": [
    {
      title: "Desarrollo Web",
      description: "Creamos sitios web modernos, funcionales y adaptativos que se ajustan a tus necesidades y objetivos comerciales, garantizando una experiencia de usuario excepcional.",
      image: desarrolloWeb.src
    },
    {
      title: "Desarrollo M\xF3vil",
      description: "Desarrollamos aplicaciones m\xF3viles intuitivas y eficientes para iOS y Android, adaptadas a tus requerimientos y dise\xF1adas para ofrecer una excelente experiencia al usuario.",
      image: desarrollomovil.src
    },
    {
      title: "Software de Automatizaci\xF3n",
      description: "Implementamos soluciones de software de automatizaci\xF3n para optimizar tus procesos empresariales, aumentar la eficiencia y reducir costos operativos",
      image: automatizacion.src
    },
    {
      title: "Chatbots",
      description: "Desarrollamos chatbots inteligentes que mejoran la interacci\xF3n con tus clientes, ofreciendo soporte inmediato y respuestas personalizadas las 24 horas del d\xEDa.",
      image: chatbot.src
    },
    {
      title: "Consultor\xEDa Tecnol\xF3gica",
      description: "Ofrecemos servicios de consultor\xEDa tecnol\xF3gica para ayudarte a seleccionar las mejores herramientas y estrategias para tu proyecto.",
      image: consultoria.src
    },
    {
      title: "E-commerce",
      description: "Desarrollamos plataformas de comercio electr\xF3nico seguras y escalables que facilitan la venta de tus productos y servicios en l\xEDnea",
      image: ecomerce.src
    }
  ], "client:component-hydration": "visible", "client:component-path": "@modules/ServiceCards", "client:component-export": "ServiceCards" })} ${renderComponent($$result2, "Hero", Hero, { "heroType": "textImage", "client:visible": true, "data": {
    image: {
      src: especialistas.src,
      width: 590,
      height: 300,
      alt: "Hero Image"
    },
    title: "\xA1Hagamos realidad tus ideas!",
    paragraph: "Mejoramos con tigo y encaminamos tus proyectos tecnol\xF3gicos hacia el \xE9xito con el apoyo de nuestros especialistas."
  }, "client:component-hydration": "visible", "client:component-path": "@modules/Hero", "client:component-export": "Hero" })} </main> ${renderComponent($$result2, "Footer", Footer, {})} ` })}`;
}, "C:/Proyectos/SchnauzerTech/cybernetic-free/src/pages/servicios.astro", void 0);

const $$file = "C:/Proyectos/SchnauzerTech/cybernetic-free/src/pages/servicios.astro";
const $$url = "/servicios";

export { $$Servicios as default, $$file as file, $$url as url };
