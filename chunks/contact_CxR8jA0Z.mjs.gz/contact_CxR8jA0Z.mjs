import { c as createComponent, r as renderTemplate, a as renderComponent, m as maybeRenderHead } from './astro/server_0co4pQTh.mjs';
import 'kleur/colors';
import 'html-escaper';
import { jsx, jsxs } from 'react/jsx-runtime';
import 'react';
import { T as Theme, C as Container, M as MediaQuery, F as FadeIn, p as portada, s as schnauzertech, $ as $$Layout } from './index_BGGjwlG8.mjs';
import styled from '@emotion/styled';
import { T as TextBox } from './index_BvAwbjsn.mjs';
import { H as Hero } from './index_BHZt_sSi.mjs';
import { F as Footer } from './index_D_2I4jLu.mjs';

const ContactStyled = styled.section`
    background: ${Theme.primary};
    padding-top: 90px;
    border-top-left-radius: 50px;
    border-top-right-radius: 50px;
    margin: -43px 0 90px;
    z-index: 1;
    position: relative;
    
    
`;
styled.div`
    max-width: 920px;
    margin: 100px;
    
   
`;
styled.h2`
    &,
    &:last-child {
        margin-bottom: 90px;
    }
        
`;
const ContainerStyled = styled(Container)`
    ${MediaQuery.min("xxxl")} {
        max-width: 920px;
    }
        
`;
const ContactBox = styled.div`
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 40px;
    margin: 40px 0;
    
    
    

    ${MediaQuery.max("lg")} {
        grid-template-columns: 1fr;
    }
`;

const Contact = () => {
  return /* @__PURE__ */ jsx(ContactStyled, { children: /* @__PURE__ */ jsx(ContainerStyled, { children: /* @__PURE__ */ jsxs(ContactBox, { children: [
    /* @__PURE__ */ jsx(FadeIn, { delay: 0.1, children: /* @__PURE__ */ jsxs(
      TextBox,
      {
        variant: "background-text",
        bgText: "Phone",
        boxAsLink: true,
        href: "https://wa.me/51968879263 ",
        target: "_blank",
        children: [
          /* @__PURE__ */ jsx("h3", { children: "+51 968879263" }),
          /* @__PURE__ */ jsx("p", { children: "Puedes llamarnos o escribirnos para cualquier duda o consulta y te atenderemos en la brevedad." })
        ]
      }
    ) }),
    /* @__PURE__ */ jsx(FadeIn, { delay: 0.2, children: /* @__PURE__ */ jsxs(
      TextBox,
      {
        variant: "background-text",
        bgText: "Email",
        boxAsLink: true,
        href: "mailto:schnauzertech.solutions@gmail.com",
        target: "_blank",
        children: [
          /* @__PURE__ */ jsx("h3", { children: "schnauzertech.solutions@gmail.com" }),
          /* @__PURE__ */ jsx("p", { children: "Puedes enviarnos correo para cualquier duda o consulta" })
        ]
      }
    ) })
  ] }) }) });
};

const $$Contact = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "SchanauzerTech | Contacto", "description": "YOUR META DESCRIPTION FOR SEO" }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<main class="page-content"> ${renderComponent($$result2, "Hero", Hero, { "heroType": "ParallaxImage", "client:load": true, "data": {
    image: portada.src,
    content: {
      title: "Contacto",
      paragraph: "\xBFTienes alg\xFAn problema o necesitas ayuda? \xA1Cont\xE1ctanos y te ayudaremos!"
    }
  }, "client:component-hydration": "load", "client:component-path": "@modules/Hero", "client:component-export": "Hero" })} ${renderComponent($$result2, "Hero", Hero, { "heroType": "textImage", "client:visible": true, "data": {
    image: {
      src: schnauzertech.src,
      width: 590,
      height: 300,
      alt: "Hero Image"
    },
    title: "\xA1Hagamos realidad tus ideas!",
    paragraph: "Mejoramos con tigo y encaminamos tus proyectos tecnol\xF3gicos hacia el \xE9xito con el apoyo de nuestros especialistas."
  }, "client:component-hydration": "visible", "client:component-path": "@modules/Hero", "client:component-export": "Hero" })} ${renderComponent($$result2, "ContactModule", Contact, { "client:load": true, "client:component-hydration": "load", "client:component-path": "@modules/Contact", "client:component-export": "Contact" })} </main> ${renderComponent($$result2, "Footer", Footer, {})} ` })}`;
}, "C:/Proyectos/SchnauzerTech/cybernetic-free/src/pages/contact.astro", void 0);

const $$file = "C:/Proyectos/SchnauzerTech/cybernetic-free/src/pages/contact.astro";
const $$url = "/contact";

export { $$Contact as default, $$file as file, $$url as url };
