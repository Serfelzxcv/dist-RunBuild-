import { c as createComponent, r as renderTemplate, a as renderComponent, m as maybeRenderHead } from './astro/server_0co4pQTh.mjs';
import 'kleur/colors';
import 'html-escaper';
import { p as portada, a as apasionados, h as historia, $ as $$Layout } from './index_BGGjwlG8.mjs';
import { H as Hero } from './index_BHZt_sSi.mjs';
import 'react/jsx-runtime';
import 'react';
import { F as Footer } from './index_D_2I4jLu.mjs';

const $$Nosotros = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "SchanauzerTech | Nosotros", "description": "YOUR META DESCRIPTION FOR SEO" }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<main class="page-content"> ${renderComponent($$result2, "Hero", Hero, { "heroType": "ParallaxImage", "client:visible": true, "data": {
    image: portada.src,
    content: {
      title: "Nosotros",
      paragraph: "Somos un equipo de desarrollo de software comprometido con crear soluciones innovadoras y ofrecer soporte de calidad."
    }
  }, "client:component-hydration": "visible", "client:component-path": "@modules/Hero", "client:component-export": "Hero" })} ${renderComponent($$result2, "Hero", Hero, { "heroType": "textImage", "client:visible": true, "data": {
    image: {
      src: apasionados.src,
      width: 590,
      height: 300,
      alt: "Hero Image"
    },
    title: "\xA1Apasionados por la tecnolog\xEDa!",
    paragraph: "En Schnauzer Tech, la tecnolog\xEDa no es solo nuestra especialidad, \xA1es nuestra pasi\xF3n! Nos dedicamos a transformar ideas innovadoras en soluciones tecnol\xF3gicas que potencian el \xE9xito de nuestros clientes. Nuestra misi\xF3n es mejorar contigo ofreciendote servicios y herramientas para que destaques frente a los demas"
  }, "client:component-hydration": "visible", "client:component-path": "@modules/Hero", "client:component-export": "Hero" })} ${renderComponent($$result2, "Hero", Hero, { "heroType": "textImage", "client:visible": true, "data": {
    switchPlaces: true,
    image: {
      src: historia.src,
      width: 590,
      height: 300,
      alt: "Hero Image"
    },
    title: "Nuestra Historia",
    paragraph: "En Schnauzer Tech, fundada en 2021, un grupo de desarrolladores decidi\xF3 apostar por j\xF3venes promesas del Per\xFA con gran talento. Gui\xE1ndolos en el mundo tecnol\xF3gico y convirti\xE9ndolos en destacados programadores, crecimos juntos. As\xED, seguimos evolucionando contigo."
  }, "client:component-hydration": "visible", "client:component-path": "@modules/Hero", "client:component-export": "Hero" })} </main> ${renderComponent($$result2, "Footer", Footer, {})} ` })}`;
}, "C:/Proyectos/SchnauzerTech/cybernetic-free/src/pages/nosotros.astro", void 0);

const $$file = "C:/Proyectos/SchnauzerTech/cybernetic-free/src/pages/nosotros.astro";
const $$url = "/nosotros";

export { $$Nosotros as default, $$file as file, $$url as url };
